package com.example.app;


public class App {
    public static void main(String[] args) {
        
        System.out.println(MessageOne());
        System.out.println(MessageTwo());
    }

    public static String MessageOne() {
        return "Hello World !!!";
    }

    public static String MessageTwo() {
        return "CodePipeline Success !";
    }

}
