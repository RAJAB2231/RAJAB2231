package com.example.app;

import org.junit.Assert;
import org.junit.Test;


public class AppTest {

    @Test
    public void appFirst() {
        Assert.assertTrue(true);
    }

    @Test
    public void appSecond() {
        Assert.assertFalse(false);
    }
}
